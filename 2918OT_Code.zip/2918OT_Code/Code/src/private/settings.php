<?php

$settings = [
    'sid' => 'twilio-sid-goes-here',
    'token' => 'twilio-token-goes-here',
    'key' => 'pusher-key-goes-here',
    'secret' => 'pusher-secret-goes-here',
    'app_id' => 'pusher-app-id-goes-here',
];
